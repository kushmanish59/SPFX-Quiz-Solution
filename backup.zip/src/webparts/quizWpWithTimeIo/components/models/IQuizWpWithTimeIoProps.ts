export interface IQuizWpWithTimeIoProps {
context:any
}
