export interface QuizInstructionsProps {
    context:any
}
export interface QuizInstructionsStates {
    instructions:any[];
    isLoading:boolean;
    //moveForward: boolean;
}
