export interface QuizUserDetailsProps {
    context: any;
    // getUserInfoID:any
  }
  export interface QuizUserDetailsStates {
    email: string;
    name: string;
    country: string;
    profession:string;
    countries:string[];
  }