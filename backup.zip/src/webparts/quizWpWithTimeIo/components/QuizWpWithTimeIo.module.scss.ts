/* tslint:disable */
require("./QuizWpWithTimeIo.module.css");
const styles = {
  quizWpWithTimeIo: 'quizWpWithTimeIo_77a3254b',
  teams: 'teams_77a3254b',
  welcome: 'welcome_77a3254b',
  welcomeImage: 'welcomeImage_77a3254b',
  links: 'links_77a3254b'
};

export default styles;
/* tslint:enable */