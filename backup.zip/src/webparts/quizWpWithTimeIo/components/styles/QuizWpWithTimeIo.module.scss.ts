/* tslint:disable */
require("./QuizWpWithTimeIo.module.css");
const styles = {
  quizWpWithTimeIo: 'quizWpWithTimeIo_0bbb2d45',
  teams: 'teams_0bbb2d45',
  welcome: 'welcome_0bbb2d45',
  welcomeImage: 'welcomeImage_0bbb2d45',
  links: 'links_0bbb2d45'
};

export default styles;
/* tslint:enable */