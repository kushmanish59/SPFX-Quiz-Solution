export declare const azureFunctionURL: (context: any) => Promise<string | undefined>;
export declare const TimeService: (url: string, context: any) => Promise<any>;
//# sourceMappingURL=TimeAPIService%20copy.d.ts.map