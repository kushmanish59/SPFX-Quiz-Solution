export declare const getAzureFunctionURL: (context: any, azureFunctionURLKey: string) => Promise<string | undefined>;
//# sourceMappingURL=AzureFunctionService.d.ts.map