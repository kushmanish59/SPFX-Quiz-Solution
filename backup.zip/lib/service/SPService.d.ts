export declare const updateListItem: (context: any, itemID: number, body: any, listName: string) => Promise<boolean>;
export declare const createListItem: (context: any, body: any, listName: string) => Promise<number>;
export declare const getListItems: (context: any, listName: string, params: string) => Promise<any>;
export declare const getListItemByID: (context: any, listName: string, id: number, params: string) => Promise<any>;
export declare const getConfigListItems: (context: any, key: string) => Promise<string>;
//# sourceMappingURL=SPService.d.ts.map