export declare const updateListItem: (context: any, itemID: number, body: any, listName: string) => Promise<number>;
export declare const createListItem: (context: any, body: any, listName: string) => Promise<number>;
export declare const getListItems: (context: any, listName: string, params: string) => Promise<any>;
//# sourceMappingURL=service.d.ts.map