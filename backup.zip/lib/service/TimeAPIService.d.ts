export declare const TimeService: (url: string, context: any, configBody: any) => Promise<any>;
//# sourceMappingURL=TimeAPIService.d.ts.map