export declare const ErrorLogging: (context: any, error: any, fileName: string) => Promise<number | undefined>;
//# sourceMappingURL=ErrorLogging.d.ts.map