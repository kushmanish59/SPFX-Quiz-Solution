export declare const userDetailHeaderText: string;
export declare const userDetailsValidationText: string;
export declare const quizHeaderText: string;
export declare const instructionsHeaderText: string;
export declare const resultsHeaderText: string;
export declare const timePickerPlaceholder: string;
export declare const momentTimeFormat = "hh:mm A";
export declare const momentDateFormat = "YYYY-MM-DD";
export declare const IdQueryParamName = "ID";
export declare const currentDateReplacePlaceHolder = "<currentdate>";
export declare const answerNotSelectedText = "Please enter or select an answer.";
export declare const qualificationScore = 50;
export declare const congratulationText = "Congratulations!!";
export declare const failedText = "Better luck next time!!";
export declare const reactRoutes: {
    instructions: string;
    userDetails: string;
    quiz: string;
    results: string;
};
export declare const SPLists: {
    quizResponseTitle: string;
    quizResponseInternalName: string;
    quizQuestionsMasterTitle: string;
    configListTitle: string;
    errorLogsTitle: string;
    errorLogsInternalName: string;
    quizInstructionsTitle: string;
};
export declare const SPAPIQueryString: {
    questionsQueryString: string;
    quizResultQueryString: string;
    quizInstructionsQueryString: string;
};
export declare const userResponseJsonKeys: {
    questionObjectKey: string;
    answerObjKey: string;
    correctAnswerObjKey: string;
};
export declare const AzureFunctionKeys: {
    azureFunctionGetTimeAPIURLKey: string;
};
export declare const questionMasterColumns: {
    question: string;
    answer: string;
    choices: string;
    questionType: string;
    sequence: string;
    config: string;
    APIURL: string;
};
export declare const questionTypes: {
    choice: string;
    time: string;
};
//# sourceMappingURL=constants.d.ts.map