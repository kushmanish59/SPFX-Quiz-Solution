import { Component } from 'react';
export interface AnswerFeedbackProps {
    correctAnswer: string;
    isCorrect: boolean;
}
export default class AnswerFeedback extends Component<AnswerFeedbackProps> {
    render(): void;
}
//# sourceMappingURL=ChoiceComponent.d.ts.map