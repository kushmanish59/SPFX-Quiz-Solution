import * as React from "react";
export declare const SpinnerControl: React.ForwardRefExoticComponent<React.RefAttributes<unknown>>;
//# sourceMappingURL=SpinnerControl.d.ts.map