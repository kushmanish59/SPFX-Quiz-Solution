import * as React from 'react';
export interface AnswerFeedbackProps {
    correctAnswer: string;
    isCorrect: boolean;
}
export declare const AnswerFeedback: React.ForwardRefExoticComponent<AnswerFeedbackProps & React.RefAttributes<unknown>>;
//# sourceMappingURL=AnswerFeedback.d.ts.map