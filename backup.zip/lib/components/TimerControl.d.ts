import * as React from 'react';
export interface TimerProps {
    onChange: any;
    questionID: number;
    correctAnswer: string;
    reset: boolean;
}
export declare const TimerComponent: React.ForwardRefExoticComponent<TimerProps & React.RefAttributes<unknown>>;
//# sourceMappingURL=TimerControl.d.ts.map