/// <reference types="react" />
export declare const radioButton: (radioItems: any[]) => JSX.Element;
//# sourceMappingURL=radiobutton.d.ts.map