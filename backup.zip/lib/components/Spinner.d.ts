export declare const AnswerFeedback: any;
//# sourceMappingURL=Spinner.d.ts.map