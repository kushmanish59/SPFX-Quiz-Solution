import * as React from 'react';
export interface RadioButtonProps {
    radioItems: string[];
    groupName: string;
    onChange: any;
    questionID: number;
    correctAnswer: string;
    disabled: boolean;
}
export declare const RadioButtonComponent: React.ForwardRefExoticComponent<RadioButtonProps & React.RefAttributes<unknown>>;
//# sourceMappingURL=radioButtonComponent.d.ts.map