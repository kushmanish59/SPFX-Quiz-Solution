import * as React from 'react';
import { Component } from 'react';
import { QuizQuestionsProps, QuizQuestionsStates } from './models/IQuizQuestionsModel';
export default class QuizQuestionsNext extends Component<QuizQuestionsProps, QuizQuestionsStates> {
    userResponses: any;
    questionTypeTimeAnswers: any;
    constructor(props: QuizQuestionsProps);
    handleChange: (answer: string, questionID: number, isAnswerCorrect: boolean, correctAnswer: string) => void;
    handleSubmit: (e: React.FormEvent<HTMLFormElement>) => Promise<void>;
    handleNext: () => void;
    componentDidMount(): Promise<void>;
    render(): JSX.Element;
}
//# sourceMappingURL=QuizQuestionsNext.d.ts.map