import * as React from 'react';
export interface QuizQuestionsProps {
}
export interface QuizQuestionsStates {
    name: string;
    country: string;
    q1: string;
    q2: string;
    q3: string;
}
export default class QuizQuestions extends React.Component<QuizQuestionsProps, QuizQuestionsStates> {
    constructor(props: QuizQuestionsProps);
    render(): React.ReactElement<QuizQuestionsProps>;
    handleSubmit: (e: any) => void;
}
//# sourceMappingURL=QuizQuestions%20copy.d.ts.map