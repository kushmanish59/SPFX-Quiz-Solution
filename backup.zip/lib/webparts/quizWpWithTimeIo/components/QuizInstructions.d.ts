import * as React from 'react';
import { QuizInstructionsProps, QuizInstructionsStates } from './models/IQuizInstructionsModel';
export default class QuizInstructions extends React.Component<QuizInstructionsProps, QuizInstructionsStates> {
    constructor(props: QuizInstructionsProps);
    componentDidMount(): Promise<void>;
    render(): React.ReactElement<QuizInstructionsProps>;
    handleSubmit: (e: any) => void;
}
//# sourceMappingURL=QuizInstructions.d.ts.map