import * as React from 'react';
import type { IQuizWpWithTimeIoProps } from './models/IQuizWpWithTimeIoProps';
import './styles/QuizWpWithTimeIo.css';
import 'bootstrap/dist/css/bootstrap.min.css';
export default class QuizWpWithTimeIo extends React.Component<IQuizWpWithTimeIoProps, {}> {
    constructor(props: IQuizWpWithTimeIoProps);
    render(): React.ReactElement<IQuizWpWithTimeIoProps>;
}
//# sourceMappingURL=QuizWpWithTimeIo.d.ts.map