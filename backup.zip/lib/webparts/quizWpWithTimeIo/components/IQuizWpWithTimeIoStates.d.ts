export interface IQuizWpWithTimeIoStates {
    name: string;
    country: string;
    showQuiz: boolean;
    headerText: string;
    recordID: number;
}
//# sourceMappingURL=IQuizWpWithTimeIoStates.d.ts.map