declare const styles: {
    quizWpWithTimeIo: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=QuizWpWithTimeIo.module.scss.d.ts.map