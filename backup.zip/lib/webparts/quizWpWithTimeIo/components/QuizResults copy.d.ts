import * as React from 'react';
export interface QuizResultProps {
}
export interface QuizResultStates {
    name: string;
    country: string;
    q1: string;
    q2: string;
    q3: string;
}
export default class QuizResult extends React.Component<QuizResultProps, QuizResultStates> {
    constructor(props: QuizResultProps);
    render(): React.ReactElement<QuizResultProps>;
    handleSubmit: (e: any) => void;
}
//# sourceMappingURL=QuizResults%20copy.d.ts.map