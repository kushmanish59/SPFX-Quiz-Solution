export interface IQuizWpWithTimeIoProps {
    context: any;
}
//# sourceMappingURL=IQuizWpWithTimeIoProps.d.ts.map