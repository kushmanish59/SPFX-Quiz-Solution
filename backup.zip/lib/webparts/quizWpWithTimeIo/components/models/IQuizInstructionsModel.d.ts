export interface QuizInstructionsProps {
    context: any;
}
export interface QuizInstructionsStates {
    instructions: any[];
    isLoading: boolean;
}
//# sourceMappingURL=IQuizInstructionsModel.d.ts.map