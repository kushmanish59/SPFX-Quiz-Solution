export interface QuizUserDetailsProps {
    context: any;
}
export interface QuizUserDetailsStates {
    email: string;
    name: string;
    country: string;
    profession: string;
    countries: string[];
}
//# sourceMappingURL=IQuizUserDetailsModel.d.ts.map