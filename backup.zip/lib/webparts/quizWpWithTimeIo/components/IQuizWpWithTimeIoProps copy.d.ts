export interface IQuizWpWithTimeIoProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
}
//# sourceMappingURL=IQuizWpWithTimeIoProps%20copy.d.ts.map