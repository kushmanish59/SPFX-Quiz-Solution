import * as React from 'react';
import { QuizUserDetailsProps, QuizUserDetailsStates } from './models/IQuizUserDetailsModel';
export default class QuizUserDetails extends React.Component<QuizUserDetailsProps, QuizUserDetailsStates> {
    constructor(props: QuizUserDetailsProps);
    componentDidMount(): void;
    render(): React.ReactElement<QuizUserDetailsProps>;
    handleSubmit: (e: any) => Promise<void>;
    validateEmail: (email: string) => boolean | undefined;
    validateForm: () => boolean | undefined;
    getCountries: () => string[];
}
//# sourceMappingURL=QuizUserDetails.d.ts.map