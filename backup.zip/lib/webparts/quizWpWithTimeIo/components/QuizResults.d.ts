import * as React from 'react';
export interface QuizResultProps {
    context: any;
}
export interface QuizResultStates {
    score: number;
    totalScore: number;
    isLoading: boolean;
}
export default class QuizResult extends React.Component<QuizResultProps, QuizResultStates> {
    constructor(props: QuizResultProps);
    componentDidMount(): Promise<void>;
    render(): React.ReactElement<QuizResultProps>;
    handleSubmit: (e: any) => void;
}
//# sourceMappingURL=QuizResults.d.ts.map