import * as React from 'react';
export interface QuizQuestionsProps {
    context: any;
}
export interface QuizQuestionsStates {
    name: string;
    country: string;
    q1: string;
    q2: string;
    q3: string;
}
export default class QuizQuestions extends React.Component<QuizQuestionsProps, QuizQuestionsStates> {
    inputComponentRef: any;
    constructor(props: QuizQuestionsProps);
    render(): React.ReactElement<QuizQuestionsProps>;
    componentDidMount(): Promise<void>;
    handleSubmit: (e: any) => void;
}
//# sourceMappingURL=QuizQuestions.d.ts.map